CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;

CREATE TABLE IF NOT EXISTS genero (
    id_genero INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS libro (
    id_libro INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(120) NOT NULL,
    autor VARCHAR(80) NOT NULL,
    anio_publicacion INT NOT NULL,
    ejemplares INT NOT NULL DEFAULT 0,
    id_genero INT NOT NULL,
    FOREIGN KEY (id_genero) REFERENCES genero(id_genero)
);

INSERT IGNORE INTO genero (nombre)
VALUES ('Novela'), ('Ciencia ficcion'), ('Historia'), ('Infantil');

INSERT INTO libro (titulo, autor, anio_publicacion, ejemplares, id_genero)
VALUES ('Cien anos de soledad', 'Gabriel Garcia Marquez', 1967, 8,
        (SELECT id_genero FROM genero WHERE nombre = 'Novela'));
INSERT INTO libro (titulo, autor, anio_publicacion, ejemplares, id_genero)
VALUES ('Fundacion', 'Isaac Asimov', 1951, 2,
        (SELECT id_genero FROM genero WHERE nombre = 'Ciencia ficcion'));
INSERT INTO libro (titulo, autor, anio_publicacion, ejemplares, id_genero)
VALUES ('El principito', 'Antoine de Saint-Exupery', 1943, 12,
        (SELECT id_genero FROM genero WHERE nombre = 'Infantil'));

SELECT l.id_libro, l.titulo, l.autor, l.anio_publicacion, l.ejemplares, g.nombre AS genero
FROM libro l
JOIN genero g ON l.id_genero = g.id_genero;
