package com.taller.ferreteria.model;

/**
 * Representa una herramienta del inventario.
 * Tiene validaciones en los setters de precio y cantidad.
 */
public class Herramienta {

    private int idHerramienta;
    private String nombre;
    private double precio;
    private int cantidad;
    // Composición: se guarda el objeto Tipo completo y no solo su id
    private Tipo tipo;

    public Herramienta() {
    }

    public Herramienta(int idHerramienta, String nombre, double precio, int cantidad, Tipo tipo) {
        this.idHerramienta = idHerramienta;
        this.nombre = nombre;
        setPrecio(precio);       // usa el setter para validar
        setCantidad(cantidad);   // usa el setter para validar
        this.tipo = tipo;
    }

    public int getIdHerramienta() {
        return idHerramienta;
    }

    public void setIdHerramienta(int idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    // Validación: el precio debe ser positivo
    public void setPrecio(double precio) {
        if (precio <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor que cero.");
        }
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    // Validación: no se permiten existencias negativas
    public void setCantidad(int cantidad) {
        if (cantidad < 0) {
            throw new IllegalArgumentException("La cantidad no puede ser negativa.");
        }
        this.cantidad = cantidad;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public void setTipo(Tipo tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Herramienta{" + "idHerramienta=" + idHerramienta + ", nombre='" + nombre + '\''
                + ", precio=" + precio + ", cantidad=" + cantidad
                + ", tipo=" + tipo + '}';
    }
}
