package com.taller.ferreteria.vista;

import com.taller.ferreteria.dao.HerramientaDAO;
import com.taller.ferreteria.dao.TipoDAO;
import com.taller.ferreteria.model.Herramienta;
import com.taller.ferreteria.model.Tipo;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * Ventana principal de la aplicación (Swing).
 * No contiene SQL: toda la información se pide a los DAO.
 */
public class VentanaFerreteria extends JFrame {

    // Por debajo de esta cantidad la fila se resalta
    private static final int STOCK_BAJO = 3;

    // Objetos de acceso a datos
    private final HerramientaDAO herramientaDAO = new HerramientaDAO();
    private final TipoDAO tipoDAO = new TipoDAO();

    // Campos del formulario
    private final JTextField txtNombre = new JTextField(20);
    private final JTextField txtPrecio = new JTextField(20);
    private final JTextField txtCantidad = new JTextField(20);
    private final JComboBox<Tipo> cmbTipo = new JComboBox<>();
    private final JComboBox<Tipo> cmbFiltro = new JComboBox<>();

    // Botones de acciones
    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnEliminar = new JButton("Eliminar");
    private final JButton btnLimpiar = new JButton("Limpiar");

    // Modelo de la tabla: las celdas no se pueden editar directamente
    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new Object[]{"ID", "Nombre", "Precio", "Cant.", "Tipo"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tabla = new JTable(modeloTabla);

    // Id de la herramienta cargada en el formulario (-1 significa ninguna)
    private int idActual = -1;

    public VentanaFerreteria() {
        super("Ferretería La Esquina — Inventario");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        armarFormulario();
        armarTabla();

        cargarTipos();
        registrarEventos();
        actualizarTabla();

        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(null);   // centra la ventana
    }

    // ---------- Construcción de la interfaz ----------

    // Panel superior: campos de texto, lista de tipos y botones
    private void armarFormulario() {
        JPanel campos = new JPanel(new GridBagLayout());
        campos.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        ponerFila(campos, gbc, 0, "Nombre:", txtNombre);
        ponerFila(campos, gbc, 1, "Precio:", txtPrecio);
        ponerFila(campos, gbc, 2, "Cantidad:", txtCantidad);
        ponerFila(campos, gbc, 3, "Tipo:", cmbTipo);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        JPanel superior = new JPanel(new BorderLayout());
        superior.add(campos, BorderLayout.CENTER);
        superior.add(botones, BorderLayout.SOUTH);
        add(superior, BorderLayout.NORTH);
    }

    // Agrega una fila "etiqueta + componente" al formulario
    private void ponerFila(JPanel panel, GridBagConstraints gbc, int fila,
            String texto, Component componente) {
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        panel.add(new JLabel(texto), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panel.add(componente, gbc);
    }

    // Panel central: filtro por tipo y tabla de herramientas
    private void armarTabla() {
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(220);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(80);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(60);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(120);

        // Renderer personalizado: pinta de naranja las filas con pocas unidades
        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor,
                    boolean seleccionada, boolean foco, int fila, int columna) {
                Component c = super.getTableCellRendererComponent(
                        t, valor, seleccionada, foco, fila, columna);
                if (!seleccionada) {
                    int existencias = (int) t.getModel().getValueAt(
                            t.convertRowIndexToModel(fila), 3);
                    if (existencias < STOCK_BAJO) {
                        c.setBackground(new Color(255, 224, 178));
                        c.setForeground(new Color(130, 60, 0));
                    } else {
                        c.setBackground(t.getBackground());
                        c.setForeground(t.getForeground());
                    }
                }
                return c;
            }
        });

        JPanel panelFiltro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        panelFiltro.add(new JLabel("Filtrar por tipo:"));
        panelFiltro.add(cmbFiltro);
        panelFiltro.add(new JLabel("(en naranja: quedan menos de " + STOCK_BAJO + " unidades)"));

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        centro.add(panelFiltro, BorderLayout.NORTH);
        JScrollPane desplazamiento = new JScrollPane(tabla);
        desplazamiento.setPreferredSize(new Dimension(620, 260));
        centro.add(desplazamiento, BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);
    }

    // ---------- Datos ----------

    // Llena las dos listas desplegables con los tipos guardados en la base de datos
    private void cargarTipos() {
        try {
            List<Tipo> tipos = tipoDAO.listar();
            cmbFiltro.addItem(new Tipo(0, "Todos"));   // opción para quitar el filtro
            for (Tipo t : tipos) {
                cmbTipo.addItem(t);
                cmbFiltro.addItem(t);
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    // Vuelve a consultar la base de datos y redibuja la tabla
    private void actualizarTabla() {
        try {
            Tipo filtro = (Tipo) cmbFiltro.getSelectedItem();
            List<Herramienta> lista;
            if (filtro == null || filtro.getIdTipo() == 0) {
                lista = herramientaDAO.listar();
            } else {
                lista = herramientaDAO.listarPorTipo(filtro.getIdTipo());
            }

            modeloTabla.setRowCount(0);   // borra las filas actuales
            for (Herramienta h : lista) {
                modeloTabla.addRow(new Object[]{
                    h.getIdHerramienta(),
                    h.getNombre(),
                    darFormatoPrecio(h.getPrecio()),
                    h.getCantidad(),
                    h.getTipo()
                });
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    // ---------- Eventos ----------

    private void registrarEventos() {
        btnGuardar.addActionListener(e -> guardar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiar());

        // Al cambiar el filtro se recarga la tabla
        cmbFiltro.addActionListener(e -> actualizarTabla());

        // Al seleccionar una fila se llena el formulario con sus datos
        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                cargarFilaEnFormulario();
            }
        });
    }

    // Busca en la base de datos la herramienta de la fila elegida y la muestra en el formulario
    private void cargarFilaEnFormulario() {
        int fila = tabla.getSelectedRow();
        int id = (int) modeloTabla.getValueAt(fila, 0);
        try {
            Herramienta h = herramientaDAO.buscarPorId(id);
            if (h == null) {
                mostrarError("La herramienta ya no existe en la base de datos.");
                actualizarTabla();
                return;
            }
            idActual = h.getIdHerramienta();
            txtNombre.setText(h.getNombre());
            txtPrecio.setText(darFormatoPrecio(h.getPrecio()));
            txtCantidad.setText(String.valueOf(h.getCantidad()));
            elegirTipo(h.getTipo().getIdTipo());
        } catch (SQLException ex) {
            mostrarError(ex.getMessage());
        }
    }

    // Botón Guardar: inserta una herramienta nueva
    private void guardar() {
        Herramienta h = leerDatos();
        if (h == null) {
            return;   // hubo un error y ya se mostró al usuario
        }
        try {
            if (herramientaDAO.insertar(h)) {
                JOptionPane.showMessageDialog(this, "Herramienta guardada con éxito.");
                limpiar();
                actualizarTabla();
            } else {
                mostrarError("No fue posible guardar la herramienta.");
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    // Botón Actualizar: modifica la herramienta seleccionada
    private void actualizar() {
        if (idActual == -1) {
            mostrarError("Seleccione una herramienta de la tabla para actualizarla.");
            return;
        }
        Herramienta h = leerDatos();
        if (h == null) {
            return;
        }
        h.setIdHerramienta(idActual);
        try {
            if (herramientaDAO.actualizar(h)) {
                JOptionPane.showMessageDialog(this, "Herramienta actualizada con éxito.");
                limpiar();
                actualizarTabla();
            } else {
                mostrarError("No se encontró la herramienta que se quiere actualizar.");
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    // Botón Eliminar: borra la herramienta seleccionada después de confirmar
    private void eliminar() {
        if (idActual == -1) {
            mostrarError("Seleccione una herramienta de la tabla para eliminarla.");
            return;
        }
        int respuesta = JOptionPane.showConfirmDialog(this,
                "¿Desea eliminar la herramienta \"" + txtNombre.getText() + "\"?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            if (herramientaDAO.eliminar(idActual)) {
                JOptionPane.showMessageDialog(this, "Herramienta eliminada con éxito.");
                limpiar();
                actualizarTabla();
            } else {
                mostrarError("No se encontró la herramienta que se quiere eliminar.");
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    // Botón Limpiar: deja el formulario listo para un registro nuevo
    private void limpiar() {
        txtNombre.setText("");
        txtPrecio.setText("");
        txtCantidad.setText("");
        if (cmbTipo.getItemCount() > 0) {
            cmbTipo.setSelectedIndex(0);
        }
        idActual = -1;
        tabla.clearSelection();
        txtNombre.requestFocus();
    }

    // ---------- Utilidades ----------

    // Lee y valida el formulario; devuelve null si hay un error (ya mostrado en pantalla)
    private Herramienta leerDatos() {
        String nombre = txtNombre.getText().trim();
        String textoPrecio = txtPrecio.getText().trim();
        String textoCantidad = txtCantidad.getText().trim();
        Tipo tipo = (Tipo) cmbTipo.getSelectedItem();

        if (nombre.isEmpty() || textoPrecio.isEmpty() || textoCantidad.isEmpty()) {
            mostrarError("Debe completar todos los campos.");
            return null;
        }
        if (tipo == null) {
            mostrarError("Debe elegir un tipo de herramienta.");
            return null;
        }

        double precio;
        int cantidad;
        try {
            precio = Double.parseDouble(textoPrecio.replace(',', '.'));
        } catch (NumberFormatException e) {
            mostrarError("El precio debe ser numérico (ejemplo: 18500 o 7200.50).");
            return null;
        }
        try {
            cantidad = Integer.parseInt(textoCantidad);
        } catch (NumberFormatException e) {
            mostrarError("La cantidad debe ser un número entero.");
            return null;
        }

        try {
            // Las reglas (precio > 0, cantidad >= 0) las valida la clase Herramienta
            return new Herramienta(0, nombre, precio, cantidad, tipo);
        } catch (IllegalArgumentException e) {
            mostrarError(e.getMessage());
            return null;
        }
    }

    // Selecciona en la lista el tipo que tenga el id indicado
    private void elegirTipo(int idTipo) {
        for (int i = 0; i < cmbTipo.getItemCount(); i++) {
            if (cmbTipo.getItemAt(i).getIdTipo() == idTipo) {
                cmbTipo.setSelectedIndex(i);
                return;
            }
        }
    }

    // Quita ceros sobrantes: 18500.0 se muestra como 18500
    private String darFormatoPrecio(double precio) {
        return BigDecimal.valueOf(precio).stripTrailingZeros().toPlainString();
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
