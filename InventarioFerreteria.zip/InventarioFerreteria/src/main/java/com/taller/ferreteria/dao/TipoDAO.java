package com.taller.ferreteria.dao;

import com.taller.ferreteria.conexion.Conexion;
import com.taller.ferreteria.model.Tipo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Acceso a datos de la tabla tipo.
 */
public class TipoDAO {

    // Devuelve todos los tipos ordenados alfabéticamente
    public List<Tipo> listar() throws SQLException {
        List<Tipo> tipos = new ArrayList<>();

        String sql = "SELECT id_tipo, nombre FROM tipo ORDER BY nombre";

        // try-with-resources: cierra la conexión y los recursos automáticamente
        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                tipos.add(new Tipo(
                        rs.getInt("id_tipo"),
                        rs.getString("nombre")));
            }
        }

        return tipos;
    }
}
