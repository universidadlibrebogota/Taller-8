package com.gitb.juandaaguilera.biblioteca.dao;

import com.gitb.juandaaguilera.biblioteca.conexion.Conexion;
import com.gitb.juandaaguilera.biblioteca.model.Genero;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GeneroDAO {

    public List<Genero> listar() throws SQLException {
        List<Genero> generos = new ArrayList<>();

        String sql = "SELECT id_genero, nombre FROM genero ORDER BY nombre";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                generos.add(new Genero(
                        rs.getInt("id_genero"),
                        rs.getString("nombre")));
            }
        }

        return generos;
    }
}
