package com.taller.ferreteria.model;

/**
 * Representa el tipo al que pertenece una herramienta (Manuales, Electricas, etc.).
 */
public class Tipo {

    private int idTipo;
    private String nombre;

    // Constructor vacío
    public Tipo() {
    }

    // Constructor con todos los atributos
    public Tipo(int idTipo, String nombre) {
        this.idTipo = idTipo;
        this.nombre = nombre;
    }

    public int getIdTipo() {
        return idTipo;
    }

    public void setIdTipo(int idTipo) {
        this.idTipo = idTipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Devuelve solo el nombre para que el JComboBox muestre texto legible
    @Override
    public String toString() {
        return nombre;
    }
}
