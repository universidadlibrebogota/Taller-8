# Inventario Ferretería La Esquina (Taller de Programación 1)

Integrantes:
1. Julián Felipe Salazar
2. Aguas Vanegas
3. David
4. Santiago Rodríguez

## Requisitos
- JDK 21
- Maven 3.8+ (o NetBeans con soporte Maven)
- MySQL en `localhost:3306` (XAMPP, Workbench o consola)

## Pasos para ejecutar
1. Clonar el repositorio y abrir la carpeta raíz (donde está `pom.xml`).
2. Iniciar MySQL y ejecutar el script `ferreteria.sql` (crea la base `ferreteria`, las tablas y datos de prueba).
3. Si el usuario o la contraseña de MySQL no son `root` / vacío, cambiarlos en
   `src/main/java/com/taller/ferreteria/conexion/Conexion.java`.
4. Ejecutar la clase `App` desde NetBeans, o en consola: `mvn compile exec:java`
5. En consola debe aparecer `Conexión exitosa` y se abre la ventana del inventario.

## Uso de la interfaz gráfica

Al ejecutar `App` se abre la ventana **Ferretería La Esquina — Inventario**. Los datos se guardan en MySQL, por lo que permanecen al cerrar y volver a abrir la aplicación.

- **Registrar una herramienta:** escriba nombre, precio y cantidad, elija el tipo en la lista desplegable y pulse **Guardar**.
- **Consultar:** la tabla muestra ID, nombre, precio, cantidad y tipo. Con "Filtrar por tipo" se ve solo un tipo ("Todos" muestra todo). Las herramientas con menos de 3 unidades se resaltan en naranja para saber qué reponer.
- **Actualizar:** seleccione una fila (los datos pasan al formulario), cambie lo necesario y pulse **Actualizar**.
- **Eliminar:** seleccione una fila, pulse **Eliminar** y confirme.
- **Limpiar:** vacía el formulario para un registro nuevo.

La aplicación muestra un mensaje de error si hay campos vacíos, precio o cantidad inválidos, precio menor o igual a cero, cantidad negativa o fallas de conexión con MySQL.

## Estructura
- `conexion`: clase `Conexion`
- `model`: `Tipo`, `Herramienta`
- `dao`: `TipoDAO`, `HerramientaDAO`
- `vista`: `VentanaFerreteria` (Swing)
- `App`: clase con `main`
