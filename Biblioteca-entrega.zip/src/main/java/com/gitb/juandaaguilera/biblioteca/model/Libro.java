package com.gitb.juandaaguilera.biblioteca.model;

import java.time.Year;

public class Libro {

    private int idLibro;
    private String titulo;
    private String autor;
    private int anioPublicacion;
    private int ejemplares;
    private Genero genero;

    public Libro() {
    }

    public Libro(int idLibro, String titulo, String autor, int anioPublicacion,
            int ejemplares, Genero genero) {
        this.idLibro = idLibro;
        this.titulo = titulo;
        this.autor = autor;
        setAnioPublicacion(anioPublicacion);
        setEjemplares(ejemplares);
        this.genero = genero;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        int anioActual = Year.now().getValue();
        if (anioPublicacion < 1000 || anioPublicacion > anioActual) {
            throw new IllegalArgumentException(
                    "El año de publicación debe estar entre 1000 y " + anioActual + ".");
        }
        this.anioPublicacion = anioPublicacion;
    }

    public int getEjemplares() {
        return ejemplares;
    }

    public void setEjemplares(int ejemplares) {
        if (ejemplares < 0) {
            throw new IllegalArgumentException("Los ejemplares no pueden ser negativos.");
        }
        this.ejemplares = ejemplares;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Libro{" + "idLibro=" + idLibro + ", titulo='" + titulo + '\''
                + ", autor='" + autor + '\'' + ", anioPublicacion=" + anioPublicacion
                + ", ejemplares=" + ejemplares + ", genero=" + genero + '}';
    }
}
