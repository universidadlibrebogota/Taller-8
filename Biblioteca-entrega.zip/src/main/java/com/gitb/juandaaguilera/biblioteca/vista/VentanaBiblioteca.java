package com.gitb.juandaaguilera.biblioteca.vista;

import com.gitb.juandaaguilera.biblioteca.dao.GeneroDAO;
import com.gitb.juandaaguilera.biblioteca.dao.LibroDAO;
import com.gitb.juandaaguilera.biblioteca.model.Genero;
import com.gitb.juandaaguilera.biblioteca.model.Libro;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.sql.SQLException;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class VentanaBiblioteca extends JFrame {

    private static final int EJEMPLARES_MINIMOS = 3;

    private final LibroDAO libroDAO = new LibroDAO();
    private final GeneroDAO generoDAO = new GeneroDAO();

    private final JTextField txtTitulo = new JTextField(20);
    private final JTextField txtAutor = new JTextField(20);
    private final JTextField txtAnio = new JTextField(20);
    private final JTextField txtEjemplares = new JTextField(20);
    private final JComboBox<Genero> cmbGenero = new JComboBox<>();
    private final JComboBox<Genero> cmbFiltro = new JComboBox<>();

    private final JButton btnGuardar = new JButton("Guardar");
    private final JButton btnActualizar = new JButton("Actualizar");
    private final JButton btnEliminar = new JButton("Eliminar");
    private final JButton btnLimpiar = new JButton("Limpiar");

    private final DefaultTableModel modeloTabla = new DefaultTableModel(
            new Object[]{"ID", "Título", "Autor", "Año", "Ejemplares", "Género"}, 0) {
        @Override
        public boolean isCellEditable(int fila, int columna) {
            return false;
        }
    };
    private final JTable tabla = new JTable(modeloTabla);

    private int idSeleccionado = -1;

    public VentanaBiblioteca() {
        super("Biblioteca — Catálogo de libros");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        construirFormulario();
        construirTabla();

        cargarGeneros();
        agregarEventos();
        refrescarTabla();

        pack();
        setMinimumSize(getSize());
        setLocationRelativeTo(null);
    }

    private void construirFormulario() {
        JPanel campos = new JPanel(new GridBagLayout());
        campos.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        agregarFila(campos, gbc, 0, "Título:", txtTitulo);
        agregarFila(campos, gbc, 1, "Autor:", txtAutor);
        agregarFila(campos, gbc, 2, "Año de publicación:", txtAnio);
        agregarFila(campos, gbc, 3, "Ejemplares:", txtEjemplares);
        agregarFila(campos, gbc, 4, "Género:", cmbGenero);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        botones.add(btnGuardar);
        botones.add(btnActualizar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);

        JPanel norte = new JPanel(new BorderLayout());
        norte.add(campos, BorderLayout.CENTER);
        norte.add(botones, BorderLayout.SOUTH);
        add(norte, BorderLayout.NORTH);
    }

    private void agregarFila(JPanel panel, GridBagConstraints gbc, int fila,
            String etiqueta, Component campo) {
        gbc.gridx = 0;
        gbc.gridy = fila;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        panel.add(new JLabel(etiqueta), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        panel.add(campo, gbc);
    }

    private void construirTabla() {
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        tabla.getColumnModel().getColumn(0).setPreferredWidth(40);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(220);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(160);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(60);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(80);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(120);

        tabla.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object valor,
                    boolean seleccionada, boolean foco, int fila, int columna) {
                Component c = super.getTableCellRendererComponent(
                        t, valor, seleccionada, foco, fila, columna);
                if (!seleccionada) {
                    int ejemplares = (int) t.getModel().getValueAt(
                            t.convertRowIndexToModel(fila), 4);
                    if (ejemplares < EJEMPLARES_MINIMOS) {
                        c.setBackground(new Color(255, 205, 210));
                        c.setForeground(new Color(150, 0, 0));
                    } else {
                        c.setBackground(t.getBackground());
                        c.setForeground(t.getForeground());
                    }
                }
                return c;
            }
        });

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filtro.add(new JLabel("Filtrar por género:"));
        filtro.add(cmbFiltro);
        filtro.add(new JLabel("(en rojo: menos de " + EJEMPLARES_MINIMOS + " ejemplares)"));

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        centro.add(filtro, BorderLayout.NORTH);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(680, 260));
        centro.add(scroll, BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);
    }

    private void cargarGeneros() {
        try {
            List<Genero> generos = generoDAO.listar();
            cmbFiltro.addItem(new Genero(0, "Todos"));
            for (Genero g : generos) {
                cmbGenero.addItem(g);
                cmbFiltro.addItem(g);
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    private void refrescarTabla() {
        try {
            Genero filtro = (Genero) cmbFiltro.getSelectedItem();
            List<Libro> libros;
            if (filtro == null || filtro.getIdGenero() == 0) {
                libros = libroDAO.listar();
            } else {
                libros = libroDAO.listarPorGenero(filtro.getIdGenero());
            }

            modeloTabla.setRowCount(0);
            for (Libro l : libros) {
                modeloTabla.addRow(new Object[]{
                    l.getIdLibro(),
                    l.getTitulo(),
                    l.getAutor(),
                    l.getAnioPublicacion(),
                    l.getEjemplares(),
                    l.getGenero()
                });
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    private void agregarEventos() {
        btnGuardar.addActionListener(e -> guardar());
        btnActualizar.addActionListener(e -> actualizar());
        btnEliminar.addActionListener(e -> eliminar());
        btnLimpiar.addActionListener(e -> limpiar());

        cmbFiltro.addActionListener(e -> refrescarTabla());

        tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && tabla.getSelectedRow() >= 0) {
                cargarLibroSeleccionado();
            }
        });
    }

    private void cargarLibroSeleccionado() {
        int fila = tabla.getSelectedRow();
        int id = (int) modeloTabla.getValueAt(fila, 0);
        try {
            Libro l = libroDAO.buscarPorId(id);
            if (l == null) {
                mostrarError("El libro ya no existe en la base de datos.");
                refrescarTabla();
                return;
            }
            idSeleccionado = l.getIdLibro();
            txtTitulo.setText(l.getTitulo());
            txtAutor.setText(l.getAutor());
            txtAnio.setText(String.valueOf(l.getAnioPublicacion()));
            txtEjemplares.setText(String.valueOf(l.getEjemplares()));
            seleccionarGenero(l.getGenero().getIdGenero());
        } catch (SQLException ex) {
            mostrarError(ex.getMessage());
        }
    }

    private void guardar() {
        Libro l = leerFormulario();
        if (l == null) {
            return;
        }
        try {
            if (libroDAO.insertar(l)) {
                JOptionPane.showMessageDialog(this, "Libro guardado correctamente.");
                limpiar();
                refrescarTabla();
            } else {
                mostrarError("No se pudo guardar el libro.");
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    private void actualizar() {
        if (idSeleccionado == -1) {
            mostrarError("Seleccione un libro de la tabla para actualizarlo.");
            return;
        }
        Libro l = leerFormulario();
        if (l == null) {
            return;
        }
        l.setIdLibro(idSeleccionado);
        try {
            if (libroDAO.actualizar(l)) {
                JOptionPane.showMessageDialog(this, "Libro actualizado correctamente.");
                limpiar();
                refrescarTabla();
            } else {
                mostrarError("No se encontró el libro a actualizar.");
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    private void eliminar() {
        if (idSeleccionado == -1) {
            mostrarError("Seleccione un libro de la tabla para eliminarlo.");
            return;
        }
        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Seguro que desea eliminar el libro \"" + txtTitulo.getText() + "\"?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (opcion != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            if (libroDAO.eliminar(idSeleccionado)) {
                JOptionPane.showMessageDialog(this, "Libro eliminado correctamente.");
                limpiar();
                refrescarTabla();
            } else {
                mostrarError("No se encontró el libro a eliminar.");
            }
        } catch (SQLException e) {
            mostrarError(e.getMessage());
        }
    }

    private void limpiar() {
        txtTitulo.setText("");
        txtAutor.setText("");
        txtAnio.setText("");
        txtEjemplares.setText("");
        if (cmbGenero.getItemCount() > 0) {
            cmbGenero.setSelectedIndex(0);
        }
        idSeleccionado = -1;
        tabla.clearSelection();
        txtTitulo.requestFocus();
    }

    private Libro leerFormulario() {
        String titulo = txtTitulo.getText().trim();
        String autor = txtAutor.getText().trim();
        String textoAnio = txtAnio.getText().trim();
        String textoEjemplares = txtEjemplares.getText().trim();
        Genero genero = (Genero) cmbGenero.getSelectedItem();

        if (titulo.isEmpty() || autor.isEmpty() || textoAnio.isEmpty()
                || textoEjemplares.isEmpty()) {
            mostrarError("Todos los campos son obligatorios.");
            return null;
        }
        if (genero == null) {
            mostrarError("Debe seleccionar un género.");
            return null;
        }

        int anio;
        int ejemplares;
        try {
            anio = Integer.parseInt(textoAnio);
        } catch (NumberFormatException e) {
            mostrarError("El año de publicación debe ser un número entero (ejemplo: 1967).");
            return null;
        }
        try {
            ejemplares = Integer.parseInt(textoEjemplares);
        } catch (NumberFormatException e) {
            mostrarError("Los ejemplares deben ser un número entero.");
            return null;
        }

        try {
            return new Libro(0, titulo, autor, anio, ejemplares, genero);
        } catch (IllegalArgumentException e) {
            mostrarError(e.getMessage());
            return null;
        }
    }

    private void seleccionarGenero(int idGenero) {
        for (int i = 0; i < cmbGenero.getItemCount(); i++) {
            if (cmbGenero.getItemAt(i).getIdGenero() == idGenero) {
                cmbGenero.setSelectedIndex(i);
                return;
            }
        }
    }

    private void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
