package com.taller.ferreteria.dao;

import com.taller.ferreteria.conexion.Conexion;
import com.taller.ferreteria.model.Herramienta;
import com.taller.ferreteria.model.Tipo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Acceso a datos de la tabla herramienta (CRUD completo).
 * Todas las consultas usan PreparedStatement para evitar inyección SQL.
 */
public class HerramientaDAO {

    // Consulta base con JOIN para traer también los datos del tipo
    private static final String CONSULTA_BASE
            = "SELECT h.id_herramienta, h.nombre, h.precio, h.cantidad, "
            + "t.id_tipo, t.nombre AS nombre_tipo "
            + "FROM herramienta h "
            + "INNER JOIN tipo t ON h.id_tipo = t.id_tipo ";

    // CREATE: agrega una herramienta nueva
    public boolean insertar(Herramienta h) throws SQLException {
        String sql = "INSERT INTO herramienta (nombre, precio, cantidad, id_tipo) "
                + "VALUES (?, ?, ?, ?)";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, h.getNombre());
            ps.setDouble(2, h.getPrecio());
            ps.setInt(3, h.getCantidad());
            ps.setInt(4, h.getTipo().getIdTipo());

            // Si se afectó al menos una fila, la inserción fue exitosa
            return ps.executeUpdate() > 0;
        }
    }

    // READ: lista todas las herramientas
    public List<Herramienta> listar() throws SQLException {
        List<Herramienta> herramientas = new ArrayList<>();
        String sql = CONSULTA_BASE + "ORDER BY h.id_herramienta";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                herramientas.add(convertir(rs));
            }
        }

        return herramientas;
    }

    // READ: busca una herramienta por su id (devuelve null si no existe)
    public Herramienta buscarPorId(int id) throws SQLException {
        String sql = CONSULTA_BASE + "WHERE h.id_herramienta = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return convertir(rs);
                }
            }
        }

        return null;
    }

    // UPDATE: modifica todos los datos de una herramienta existente
    public boolean actualizar(Herramienta h) throws SQLException {
        String sql = "UPDATE herramienta SET nombre = ?, precio = ?, cantidad = ?, "
                + "id_tipo = ? WHERE id_herramienta = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, h.getNombre());
            ps.setDouble(2, h.getPrecio());
            ps.setInt(3, h.getCantidad());
            ps.setInt(4, h.getTipo().getIdTipo());
            ps.setInt(5, h.getIdHerramienta());

            return ps.executeUpdate() > 0;
        }
    }

    // DELETE: elimina una herramienta por su id
    public boolean eliminar(int id) throws SQLException {
        String sql = "DELETE FROM herramienta WHERE id_herramienta = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;
        }
    }

    // Extra: lista solo las herramientas de un tipo (para el filtro de la ventana)
    public List<Herramienta> listarPorTipo(int idTipo) throws SQLException {
        List<Herramienta> herramientas = new ArrayList<>();
        String sql = CONSULTA_BASE
                + "WHERE t.id_tipo = ? ORDER BY h.id_herramienta";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idTipo);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    herramientas.add(convertir(rs));
                }
            }
        }

        return herramientas;
    }

    // Convierte la fila actual del ResultSet en un objeto Herramienta con su Tipo
    private Herramienta convertir(ResultSet rs) throws SQLException {
        Tipo tipo = new Tipo(
                rs.getInt("id_tipo"),
                rs.getString("nombre_tipo"));

        return new Herramienta(
                rs.getInt("id_herramienta"),
                rs.getString("nombre"),
                rs.getDouble("precio"),
                rs.getInt("cantidad"),
                tipo);
    }
}
