-- Taller: Inventario de la Ferretería La Esquina
CREATE DATABASE IF NOT EXISTS ferreteria;
USE ferreteria;

-- Tabla de tipos de herramienta (lado "uno" de la relación)
CREATE TABLE IF NOT EXISTS tipo (
    id_tipo INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

-- Tabla de herramientas (lado "muchos"), cada una pertenece a un tipo
CREATE TABLE IF NOT EXISTS herramienta (
    id_herramienta INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(80) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    cantidad INT NOT NULL DEFAULT 0,
    id_tipo INT NOT NULL,
    FOREIGN KEY (id_tipo) REFERENCES tipo(id_tipo)
);

INSERT IGNORE INTO tipo (nombre)
VALUES ('Manuales'), ('Electricas'), ('Pinturas'), ('Fijacion');

-- Herramientas de prueba
INSERT INTO herramienta (nombre, precio, cantidad, id_tipo)
VALUES ('Martillo de acero', 18500, 12, (SELECT id_tipo FROM tipo WHERE nombre = 'Manuales'));
INSERT INTO herramienta (nombre, precio, cantidad, id_tipo)
VALUES ('Taladro 600 W', 145000, 4, (SELECT id_tipo FROM tipo WHERE nombre = 'Electricas'));
INSERT INTO herramienta (nombre, precio, cantidad, id_tipo)
VALUES ('Tornillos 1 pulgada (caja)', 7200, 40, (SELECT id_tipo FROM tipo WHERE nombre = 'Fijacion'));

-- Verificación de los datos insertados
SELECT h.id_herramienta, h.nombre, h.precio, h.cantidad, t.nombre AS tipo
FROM herramienta h
JOIN tipo t ON h.id_tipo = t.id_tipo;

-- Prueba de llave foránea (ejecutar a mano para ver el error):
-- DELETE FROM tipo WHERE nombre = 'Manuales';
