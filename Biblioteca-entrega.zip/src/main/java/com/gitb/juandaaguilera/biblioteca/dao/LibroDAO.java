package com.gitb.juandaaguilera.biblioteca.dao;

import com.gitb.juandaaguilera.biblioteca.conexion.Conexion;
import com.gitb.juandaaguilera.biblioteca.model.Genero;
import com.gitb.juandaaguilera.biblioteca.model.Libro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO {

    private static final String SELECT_CON_GENERO
            = "SELECT l.id_libro, l.titulo, l.autor, l.anio_publicacion, l.ejemplares, "
            + "g.id_genero, g.nombre AS nombre_genero "
            + "FROM libro l "
            + "INNER JOIN genero g ON l.id_genero = g.id_genero ";

    public boolean insertar(Libro l) throws SQLException {
        String sql = "INSERT INTO libro (titulo, autor, anio_publicacion, ejemplares, id_genero) "
                + "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, l.getTitulo());
            ps.setString(2, l.getAutor());
            ps.setInt(3, l.getAnioPublicacion());
            ps.setInt(4, l.getEjemplares());
            ps.setInt(5, l.getGenero().getIdGenero());

            return ps.executeUpdate() > 0;
        }
    }

    public List<Libro> listar() throws SQLException {
        List<Libro> libros = new ArrayList<>();
        String sql = SELECT_CON_GENERO + "ORDER BY l.id_libro";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                libros.add(mapear(rs));
            }
        }

        return libros;
    }

    public Libro buscarPorId(int id) throws SQLException {
        String sql = SELECT_CON_GENERO + "WHERE l.id_libro = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapear(rs);
                }
            }
        }

        return null;
    }

    public boolean actualizar(Libro l) throws SQLException {
        String sql = "UPDATE libro SET titulo = ?, autor = ?, anio_publicacion = ?, "
                + "ejemplares = ?, id_genero = ? WHERE id_libro = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, l.getTitulo());
            ps.setString(2, l.getAutor());
            ps.setInt(3, l.getAnioPublicacion());
            ps.setInt(4, l.getEjemplares());
            ps.setInt(5, l.getGenero().getIdGenero());
            ps.setInt(6, l.getIdLibro());

            return ps.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int id) throws SQLException {
        String sql = "DELETE FROM libro WHERE id_libro = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;
        }
    }

    public List<Libro> listarPorGenero(int idGenero) throws SQLException {
        List<Libro> libros = new ArrayList<>();
        String sql = SELECT_CON_GENERO
                + "WHERE g.id_genero = ? ORDER BY l.id_libro";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idGenero);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    libros.add(mapear(rs));
                }
            }
        }

        return libros;
    }

    private Libro mapear(ResultSet rs) throws SQLException {
        Genero genero = new Genero(
                rs.getInt("id_genero"),
                rs.getString("nombre_genero"));

        return new Libro(
                rs.getInt("id_libro"),
                rs.getString("titulo"),
                rs.getString("autor"),
                rs.getInt("anio_publicacion"),
                rs.getInt("ejemplares"),
                genero);
    }
}
