package com.taller.ferreteria;

import com.taller.ferreteria.conexion.Conexion;
import com.taller.ferreteria.vista.VentanaFerreteria;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

/**
 * Clase principal: prueba la conexión y abre la ventana.
 */
public class App {

    public static void main(String[] args) {
        // Se prueba la conexión antes de mostrar la interfaz
        try (Connection con = Conexion.getConexion()) {
            System.out.println("Conexión exitosa");
        } catch (SQLException e) {
            // El detalle del error ya se imprimió en la clase Conexion
            System.err.println("La prueba de conexión falló.");
        }

        // Usa el aspecto visual del sistema operativo
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Si falla, Swing usa su aspecto por defecto
        }

        // Las ventanas Swing se crean en el hilo de eventos
        SwingUtilities.invokeLater(() -> new VentanaFerreteria().setVisible(true));
    }
}
