package com.gitb.juandaaguilera.biblioteca;

import com.gitb.juandaaguilera.biblioteca.conexion.Conexion;
import com.gitb.juandaaguilera.biblioteca.vista.VentanaBiblioteca;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class App {

    public static void main(String[] args) {
        try (Connection con = Conexion.getConexion()) {
            System.out.println("Conexión exitosa");
        } catch (SQLException e) {
            System.err.println("Fallo la prueba de conexión.");
        }

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
        }

        SwingUtilities.invokeLater(() -> new VentanaBiblioteca().setVisible(true));
    }
}
