# Biblioteca — Catálogo de libros (Taller 8, Programación 1)

1. Juan David Aguilera
2. Marianna Fernandez 
3. JeanCarlo Caicedo

## Requisitos
- JDK 21
- Maven 3.8+ (o NetBeans con soporte Maven)
- MySQL en `localhost:3306` (XAMPP, Workbench o consola)

## Pasos para ejecutar
1. Clonar el repositorio y abrir la carpeta raíz (donde está `pom.xml`).
2. Iniciar MySQL y ejecutar el script `biblioteca.sql` (crea la base `biblioteca`, las tablas y datos de prueba).
3. Si el usuario o la contraseña de MySQL no son `root` / vacío, cambiarlos en
   `src/main/java/com/gitb/juandaaguilera/biblioteca/conexion/Conexion.java`.
4. Ejecutar la clase `App` desde NetBeans, o en consola: `mvn compile exec:java`
5. En consola debe aparecer `Conexión exitosa` y se abre la ventana de la biblioteca.

## Uso de la interfaz gráfica

Al ejecutar `App` se abre la ventana **Biblioteca — Catálogo de libros**. Los datos se guardan en MySQL, así que siguen ahí al cerrar y volver a abrir la aplicación.

- **Registrar un libro:** escriba el título, el autor, el año de publicación y los ejemplares disponibles, elija el género en la lista desplegable y pulse **Guardar**. El libro aparece en la tabla.
- **Consultar:** la tabla muestra todos los libros con su ID, título, autor, año, ejemplares y género. Para ver solo un género, use el filtro "Filtrar por género" (la opción "Todos" muestra todo). Los libros con menos de 3 ejemplares se resaltan en rojo, para saber cuáles conviene reponer.
- **Actualizar un libro:** haga clic en su fila de la tabla (los datos se cargan en el formulario), modifique lo que necesite y pulse **Actualizar**.
- **Eliminar un libro:** haga clic en su fila, pulse **Eliminar** y confirme en el cuadro de diálogo.
- **Limpiar:** vacía el formulario para empezar un registro nuevo.

Si hay un error (campos vacíos, año o ejemplares que no son números, año fuera del rango 1000 – año actual, ejemplares negativos o fallas de conexión con MySQL), la aplicación muestra un mensaje de error en pantalla.

## Estructura
- `conexion`: clase `Conexion`
- `model`: `Genero`, `Libro`
- `dao`: `GeneroDAO`, `LibroDAO`
- `vista`: `VentanaBiblioteca` (Swing)
- `App`: clase con `main`
