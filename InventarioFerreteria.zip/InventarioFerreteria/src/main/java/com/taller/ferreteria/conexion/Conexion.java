package com.taller.ferreteria.conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Clase que concentra la conexión con MySQL.
 * Los DAO llaman a getConexion() cada vez que necesitan ejecutar una consulta.
 */
public class Conexion {

    // Dirección de la base de datos (host, puerto y nombre)
    private static final String URL
            = "jdbc:mysql://localhost:3306/ferreteria"
            + "?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";

    // Credenciales: cambiar si MySQL usa otro usuario o contraseña
    private static final String USUARIO = "root";
    private static final String CLAVE = "";

    public static Connection getConexion() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USUARIO, CLAVE);
        } catch (SQLException e) {
            String mensaje = "No fue posible conectar con la base de datos 'ferreteria'. "
                    + "Revise que MySQL esté iniciado, que la base de datos exista "
                    + "y que el usuario y la clave sean correctos. "
                    + "Detalle: " + e.getMessage();
            System.err.println(mensaje);
            // Se lanza de nuevo con un mensaje claro para mostrarlo en la ventana
            throw new SQLException(mensaje, e);
        }
    }
}
